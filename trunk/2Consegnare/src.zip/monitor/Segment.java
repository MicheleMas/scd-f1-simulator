import java.awt.Point;

public interface Segment {

	public Point getPosition(int progress);

}