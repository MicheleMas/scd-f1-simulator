java -cp ../../../yami4/lib/yami4.jar:. Monitor tcp://localhost:12346 tcp://localhost:12347
